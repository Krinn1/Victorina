package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class QuizActivity extends AppCompatActivity {

    private TextView questions;
    private TextView question;

    private AppCompatButton option1, option2, option3, option4;
    private AppCompatButton next;


    private List<QuestionsList> questionsList;

    private int currentQuestion = 0;
    private String selectedOptionUser = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // приаязка id

        final ImageView back = findViewById(R.id.back);
        final TextView selectedTopicName = findViewById(R.id.selectedTopicName);

        questions = findViewById(R.id.questions);
        question = findViewById(R.id.question);

        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);

        next = findViewById(R.id.next);

        final String getSelectedTopic = getIntent().getStringExtra("selectedTopic");

        selectedTopicName.setText(getSelectedTopic);

        questionsList = QuestionsAll.getQuestions(getSelectedTopic);



        // варианты ответа викторины
        questions.setText((currentQuestion + 1) + "/" + questionsList.size());
        question.setText(questionsList.get(0).getQuestion());
        option1.setText(questionsList.get(0).getOption1());
        option2.setText(questionsList.get(0).getOption2());
        option3.setText(questionsList.get(0).getOption3());
        option4.setText(questionsList.get(0).getOption4());

        back.setOnClickListener(new View.OnClickListener() {
            //back
            @Override
            public void onClick(View view) {

                startActivity(new Intent(QuizActivity.this, SecondActivity.class));
                finish();
            }
        });

        // осуществление выбора ответа в викторине правильных и неправильных ответов

        option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedOptionUser.isEmpty()) {

                    selectedOptionUser = option1.getText().toString();
                    option1.setBackgroundResource(R.drawable.selected_question_incorrect);
                    option1.setTextColor(Color.WHITE);

                    Answer();
                    questionsList.get(currentQuestion).setUserSelectedAnswer(selectedOptionUser);
                }
            }
        });

        option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedOptionUser.isEmpty()) {

                    selectedOptionUser = option2.getText().toString();
                    option2.setBackgroundResource(R.drawable.selected_question_incorrect);
                    option2.setTextColor(Color.WHITE);

                    Answer();
                    questionsList.get(currentQuestion).setUserSelectedAnswer(selectedOptionUser);
                }


            }
        });

        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedOptionUser.isEmpty()) {

                    selectedOptionUser = option3.getText().toString();
                    option3.setBackgroundResource(R.drawable.selected_question_incorrect);
                    option3.setTextColor(Color.WHITE);

                    Answer();
                    questionsList.get(currentQuestion).setUserSelectedAnswer(selectedOptionUser);
                }

            }
        });

        option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedOptionUser.isEmpty()) {

                    selectedOptionUser = option4.getText().toString();
                    option4.setBackgroundResource(R.drawable.selected_question_incorrect);
                    option4.setTextColor(Color.WHITE);

                    Answer();
                    questionsList.get(currentQuestion).setUserSelectedAnswer(selectedOptionUser);
                }

            }
        });

        // осуществелние кнопки next на следующий вопрос

        next.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                if (selectedOptionUser.isEmpty()) {
                    Toast.makeText(QuizActivity.this, "Выберите вариант ответа", Toast.LENGTH_SHORT).show();
                } else {
                    changeNextQuestion();

                }

            }
        });


    }



    // правельные ответы викторины
    private int getCorrectAnswers() {

        int correctAnswers = 0;

        for (int i = 0; i < questionsList.size(); i++) {

            final String getUserSelectedAnswer = questionsList.get(i).getUserSelectedAnswer();
            final String getAnswer = questionsList.get(i).getAnswer();

            if (getUserSelectedAnswer.equals(getAnswer)) {
                correctAnswers++;
            }
        }

        return correctAnswers;
    }

    // неправильные ответы викторины
    private int getInCorrectAnswers() {

        int correctAnswers = 0;

        for (int i = 0; i < questionsList.size(); i++) {

            final String getUserSelectedAnswer = questionsList.get(i).getUserSelectedAnswer();
            final String getAnswer = questionsList.get(i).getAnswer();

            if (!getUserSelectedAnswer.equals(getAnswer)) {
                correctAnswers++;
            }
        }

        return correctAnswers;
    }

    // back

    @Override
    public void onBackPressed() {
        startActivity(new Intent(QuizActivity.this, SecondActivity.class));
        finish();
    }

    // метод выбора одного ответа

    private void Answer() {
        final String getAnswer = questionsList.get(currentQuestion).getAnswer();

        if (option1.getText().toString().equals(getAnswer)) {
            option1.setBackgroundResource(R.drawable.selected_question_correct);
            option1.setTextColor(Color.WHITE);

        } else if (option2.getText().toString().equals(getAnswer)) {
            option2.setBackgroundResource(R.drawable.selected_question_correct);
            option2.setTextColor(Color.WHITE);


        } else if (option3.getText().toString().equals(getAnswer)) {
            option3.setBackgroundResource(R.drawable.selected_question_correct);
            option3.setTextColor(Color.WHITE);


        } else if (option4.getText().toString().equals(getAnswer)) {
            option4.setBackgroundResource(R.drawable.selected_question_correct);
            option4.setTextColor(Color.WHITE);


        }
    }

    private void changeNextQuestion() {
        currentQuestion++;



            // сбросить предыдущий ответ
            if (currentQuestion < questionsList.size()) {
                selectedOptionUser = "";

                // сбрасывание фона вопроса
                option1.setBackgroundResource(R.drawable.question_button);
                option1.setTextColor(Color.parseColor("#4E63A7"));

                option2.setBackgroundResource(R.drawable.question_button);
                option2.setTextColor(Color.parseColor("#4E63A7"));

                option3.setBackgroundResource(R.drawable.question_button);
                option3.setTextColor(Color.parseColor("#4E63A7"));

                option4.setBackgroundResource(R.drawable.question_button);
                option4.setTextColor(Color.parseColor("#4E63A7"));

                // список новых вопросов
                questions.setText((currentQuestion + 1) + "/" + questionsList.size());
                question.setText(questionsList.get(currentQuestion).getQuestion());
                option1.setText(questionsList.get(currentQuestion).getOption1());
                option2.setText(questionsList.get(currentQuestion).getOption2());
                option3.setText(questionsList.get(currentQuestion).getOption3());
                option4.setText(questionsList.get(currentQuestion).getOption4());

            } else {
                Intent intent = new Intent(QuizActivity.this, QuizResults.class);
                intent.putExtra("correct",getCorrectAnswers() );
                intent.putExtra("incorrect", getInCorrectAnswers());

                startActivity(intent);
                finish();
            }

        }
    }


