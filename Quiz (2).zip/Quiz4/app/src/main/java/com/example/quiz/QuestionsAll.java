package com.example.quiz;

import android.widget.Switch;

import java.util.ArrayList;
import java.util.List;

public class QuestionsAll {

//     Викторина про информатику

    private static  List<QuestionsList> informaticsQuestions () {
        final List<QuestionsList> questionsList = new ArrayList<>();

        final QuestionsList question1 = new QuestionsList("Для разработки медицинских приложений",
                "Для забавы",
                "Для разработки программ",
                "Для программирования бытовых электронных устройств",
                "Для чего изначально разрабатывался язык программирования Java?",
                "Для программирования бытовых электронных устройств",

        "");
        final QuestionsList question2 = new QuestionsList("Fifa",
                "C",
                "Python",
                "Go",
                "Какой язык программирования лежит в основе Java?",
                "C",
                "");

        final QuestionsList question3 = new QuestionsList("Акселерометр",
                "Крикометр",
                "Слухометр",
                "Каниктинометр",
                "Какой датчик есть в Android?",
                "Акселерометр",
                "");

        final QuestionsList question4 = new QuestionsList("Начало и конец жизни ПО",
                "Цикл выключения ПО",
                "Период времени, который начинается с момента принятия решения",
                "Что-то из биологии",
                "Что такое жизненный цикл?",
                "Период времени, который начинается с момента принятия решения",
                "");

        final QuestionsList question5 = new QuestionsList("Создаёт и отображает всплывающие сообщение",
                "Завершает жизненный цикл",
                "Создаёт класс",
                "Вывадит на экран предупредение",
                "Что делает class toast?",
                "Создаёт и отображает всплывающие сообщение",
                "");

        final QuestionsList question6 = new QuestionsList("Способность удалять приложение ",
                "Это способ блокировки приложения ",
                "Это способ передачи картинок",
                "Это упаковка данных и функций в один компонент",
                "Что такое инкапсуляция?",
                "Это упаковка данных и функций в один компонент",
                "");

        final QuestionsList question7 = new QuestionsList("Red Hat",
                "Компания Sun Microsystems",
                "Илон Маск",
                "Райан Гослинг",
                "Кто создал java?",
                "Компания Sun Microsystems",
                "");

        final QuestionsList question8 = new QuestionsList("HTML",
                "JSON",
                "HTTP",
                "XML",
                "По какому протоколу осуществляется связь между мобильным приложением и сервером в клиент-серверном приложении?",
                "HTTP",
                "");

        final QuestionsList question9 = new QuestionsList("Архивирования данных для долгого хранения",
                "Установлению связи между данными и отображением их на экране смартфона",
                "Конвертирования данных в бинарный поток",
                "Установлению связи между данными и хранением их в ресурсах",
                "При работе с данными для каких целей предназначен адаптер?",
                "Конвертирования данных в бинарный поток",
                "");

        final QuestionsList question10 = new QuestionsList("Базовый",
                "Информационный",
                "Физический",
                "Геологический",
                "Какой тип данных есть? ",
                "Базовый",
                "");

        questionsList.add(question1);
        questionsList.add(question2);
        questionsList.add(question3);
        questionsList.add(question4);
        questionsList.add(question5);
        questionsList.add(question6);
        questionsList.add(question7);
        questionsList.add(question8);
        questionsList.add(question9);
        questionsList.add(question10);

        return questionsList;
    }
   // викторина про котов
   private static  List<QuestionsList> catQuestion () {
       final List<QuestionsList> questionsList = new ArrayList<>();

       final QuestionsList question1 = new QuestionsList("Хомяка",
               "Кошку",
               "Собаку",
               "Ежа",
               "Какое животное, согласно русской традиции, первым пускают в новый дом для того, чтобы изгнать злой дух?",
               "Кошку",

               "");
       final QuestionsList question2 = new QuestionsList("370 млн",
               "550 млн",
               "210 млн",
               "400 млн",
               "Сколько домашних кошек насчитывается в мире по данным Лионского университета (Франция)?",
               "400 млн",
               "");

       final QuestionsList question3 = new QuestionsList("В Венеции",
               "В Праге",
               "В Стамбуле",
               "В Сеуле",
               "В каком городе кошки являются его полноправными жителями, а горожане о них заботятся и даже строят целые кошачьи деревни?",
               "В Стамбуле",
               "");

       final QuestionsList question4 = new QuestionsList("В Берлине",
               "В Нью-Йорке",
               "В Сеуле",
               "В Токио",
               "В каком городе в 1895 году состоялась самая первая выставка кошек?",
               "В Нью-Йорке",
               "");

       final QuestionsList question5 = new QuestionsList("Холодную погоду",
               "Жаркую погоду",
               "Дождливую погоду",
               "Ветряную погоду",
               "Какую погоду следует ожидать, если кошка свернулась в клубочек и закрыла хвостом нос?",
               "Холодную погоду",
               "");

       final QuestionsList question6 = new QuestionsList("В Канаде",
               "В Австралии",
               "В Германии",
               "В России",
               "В какой стране люди больше всех заводят себе кошек в качестве домашнего животного?",
               "В Австралии",
               "");

       final QuestionsList question7 = new QuestionsList("В Перу",
               "В Китае",
               "В Индии",
               "В Египте",
               "В какой стране домашняя кошка почти не встречается?",
               "В Перу",
               "");

       final QuestionsList question8 = new QuestionsList("В Италии",
               "В Германии",
               "В Мексике",
               "В Китае",
               "В какой стране создан музей кошек, в котором насчитывается более 2500 тысяч экспонатов?",
               "В Германии",
               "");

       final QuestionsList question9 = new QuestionsList("Канадский сфинкс",
               "Саванна",
               "Мейн-кун",
               "Девон-рекс",
               "Какая порода кошек считается самой дорогой из ныне существующих пород?",
               "Саванна",
               "");

       final QuestionsList question10 = new QuestionsList("Около 100",
               "Около 60",
               "Около 50",
               "Около 20",
               "Сколько разнообразных звуков может издавать кошка?",
               "Около 100",
               "");
       questionsList.add(question1);
       questionsList.add(question2);
       questionsList.add(question3);
       questionsList.add(question4);
       questionsList.add(question5);
       questionsList.add(question6);
       questionsList.add(question7);
       questionsList.add(question8);
       questionsList.add(question9);
       questionsList.add(question10);


       return questionsList;

   }

    public  static List<QuestionsList> getQuestions (String selectedTopicName){
        switch (selectedTopicName) {
           case "Информатика" : return informaticsQuestions();
              default: return  catQuestion();

        }
    }
}
