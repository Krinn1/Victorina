package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {
    // выделение икнонки викторины
    private String selectedTopic = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // присваивание id

        final LinearLayout informatics = findViewById(R.id.informaticsLayout); // id  викторины информатики
        final LinearLayout cat = findViewById(R.id.catLayout); // id викторины про котов

        final Button startQuiz = findViewById(R.id.startQuiz);

        informatics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedTopic = "Информатика";
                informatics.setBackgroundResource(R.drawable.selected_topic);
                cat.setBackgroundResource(R.drawable.backgroud_button);

            }
        });

        cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedTopic = "Коты";
                cat.setBackgroundResource(R.drawable.selected_topic);
                informatics.setBackgroundResource(R.drawable.backgroud_button);


            }
        });



        startQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedTopic.isEmpty()) {
                    Toast.makeText(SecondActivity.this, "Выберите викторину", Toast.LENGTH_SHORT).show(); // Пользователь не выбрал викторину
                }  else  {
                    Intent intent = new Intent(SecondActivity.this, QuizActivity.class); //
                    intent.putExtra("selectedTopic", selectedTopic);
                    startActivity(intent);
                    finish();
                }
            }
        });


    }
}

